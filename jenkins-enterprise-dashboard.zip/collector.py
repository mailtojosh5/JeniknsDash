
import requests
import sqlite3

JENKINS_URL = "http://localhost:8080"

conn = sqlite3.connect("dashboard.db")
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS builds (
job TEXT,
build INT,
status TEXT,
timestamp INT
)
""")

def get_jobs(url):

    api = f"{url}/api/json?tree=jobs[name,url]"
    r = requests.get(api)

    jobs = []

    for j in r.json().get("jobs", []):

        if "/job/" in j["url"]:
            jobs.append(j)

    return jobs

def get_last_build(job):

    api = f"{job['url']}/lastBuild/api/json"

    r = requests.get(api)

    if r.status_code != 200:
        return None

    return r.json()

jobs = get_jobs(JENKINS_URL)

for job in jobs:

    build = get_last_build(job)

    if not build:
        continue

    cur.execute(
        "INSERT INTO builds VALUES (?,?,?,?)",
        (
            job["name"],
            build["number"],
            build.get("result"),
            build.get("timestamp"),
        ),
    )

conn.commit()
conn.close()

print("Collected Jenkins build data")
