
import sqlite3
import json

conn = sqlite3.connect("dashboard.db")
cur = conn.cursor()

data = cur.execute(
    "SELECT status, COUNT(*) FROM builds GROUP BY status"
).fetchall()

summary = {"SUCCESS":0,"FAILURE":0,"OTHER":0}

for row in data:

    status = row[0]

    if status == "SUCCESS":
        summary["SUCCESS"] += row[1]
    elif status == "FAILURE":
        summary["FAILURE"] += row[1]
    else:
        summary["OTHER"] += row[1]

html = f"""
<html>
<head>
<title>Jenkins Test Analytics</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

<h1>Jenkins Test Dashboard</h1>

<canvas id="summary"></canvas>

<script>

const data = {{
labels:["Passed","Failed","Other"],
datasets:[{{

data:[{summary["SUCCESS"]},{summary["FAILURE"]},{summary["OTHER"]}],
backgroundColor:["green","red","gray"]

}}]
}}

new Chart(
document.getElementById("summary"),
{{type:"pie",data:data}}
)

</script>

</body>
</html>
"""

open("dashboard.html","w").write(html)

print("Dashboard generated")
