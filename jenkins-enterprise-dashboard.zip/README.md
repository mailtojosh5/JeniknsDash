
# Jenkins Enterprise Test Dashboard (No Docker, No Token)

Features:
- Automatically scans all Jenkins folders and jobs
- Works from inside Jenkins using localhost API (no token required)
- Parses Allure, Cucumber, and JUnit reports
- Stores history in SQLite
- Detects flaky tests
- Generates HTML dashboard with charts
- Publishable using Jenkins HTML Publisher plugin

## Setup (Ubuntu Jenkins)

Install dependencies:

pip3 install -r requirements.txt

## Run Collector

python3 collector.py

## Generate Dashboard

python3 generate_dashboard.py

## Jenkins Pipeline

Use the provided Jenkinsfile to run automatically and publish dashboard.
