
import sqlite3

conn = sqlite3.connect("dashboard.db")
cur = conn.cursor()

query = """
SELECT job
FROM builds
GROUP BY job
HAVING COUNT(DISTINCT status) > 1
"""

rows = cur.execute(query).fetchall()

print("Flaky Jobs:")

for r in rows:
    print(r[0])
