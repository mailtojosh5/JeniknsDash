# Xray Test Report — Node Server

Fetches Xray Cloud test data **through your corporate proxy** and renders the rich HTML dashboard.

## Structure

```
xray-report/
├── src/
│   └── server.js          ← Node.js Express server (proxy-aware)
├── public/
│   └── index.html         ← Dashboard UI (fetches /api/report)
├── package.json
├── .env.example           ← Copy to .env and fill in
└── Jenkinsfile            ← CI pipeline
```

## Quick Start

```bash
# 1. Install
cd xray-report
npm install

# 2. Configure
cp .env.example .env
# Edit .env:
#   XRAY_CLIENT_ID=...
#   XRAY_CLIENT_SECRET=...
#   HTTPS_PROXY=https://proxy.yourcorp.com:8080
#   PROJECT_KEYS=QA,SHOP,PLAT

# 3. Run
npm start
# → http://localhost:3000
```

## How It Works

```
Browser → localhost:3000/           (serves dashboard HTML)
Browser → localhost:3000/api/report (user clicks "Fetch & Generate")
  └→ Node server
       └→ HTTPS_PROXY → xray.cloud.getxray.app  (auth + GraphQL)
            └→ data returned to browser as JSON
```

The corporate proxy issue is solved because **all Xray API calls happen on the server**, not in the browser. The browser only ever talks to `localhost`.

## Jenkins Setup

1. Add credentials in Jenkins → Manage Jenkins → Credentials:
   - `XRAY_CLIENT_ID` (Secret text)
   - `XRAY_CLIENT_SECRET` (Secret text)

2. Set global env vars (Manage Jenkins → System → Global properties):
   - `HTTPS_PROXY` = your proxy URL

3. Create a Pipeline job pointing at this repo, using `Jenkinsfile`.

4. Install the [HTML Publisher plugin](https://plugins.jenkins.io/htmlpublisher/) to view the report inline in Jenkins.

5. Run — the report is published as a build artifact and in the HTML Report tab.

## API

| Endpoint | Description |
|---|---|
| `GET /` | Dashboard HTML |
| `GET /api/report?projects=QA,SHOP&days=30` | Fetch live Xray data (JSON) |
| `GET /health` | Health check (for Jenkins/k8s probes) |

`projects` and `days` default to `PROJECT_KEYS` and `DATE_RANGE_DAYS` from `.env` if not passed.

## Proxy Notes

- Set `HTTPS_PROXY` to your proxy URL in `.env`
- If your proxy uses a **self-signed CA**, set `NODE_EXTRA_CA_CERTS=/path/to/ca.pem`
- `npm install` also uses the proxy via `NPM_CONFIG_PROXY` (set in Jenkinsfile)
