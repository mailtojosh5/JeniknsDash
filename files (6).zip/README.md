# Running the Xray report from Jenkins (proxy-safe)

## Why this exists
The original dashboard fetches Xray Cloud data with browser `fetch()`, which has no way to use `https_proxy`/`HTTPS_PROXY` — that's a Node/curl-only convention, not something browsers honor. Running it from Jenkins flips the order: a Node script does the fetching server-side (where the proxy env var actually works), then bakes the results into a copy of the HTML. The output file needs zero network calls to view — open it in any browser, anywhere, proxy or not.

## Files
- `generate-xray-report.mjs` — Node script that authenticates, queries Xray Cloud, and injects the data into the HTML template.
- `xray_report_template.html` — your original dashboard, with one small addition: if it finds `window.__PRELOADED__` already set, it renders immediately instead of showing the login screen.
- `package.json` — declares the one dependency (`undici`) needed to make Node's `fetch` proxy-aware.

## One-time setup on the Jenkins agent
```bash
npm install
```

## Running it
```bash
export https_proxy=http://proxy.xxx.com:8080
export XRAY_CLIENT_ID=your_client_id
export XRAY_CLIENT_SECRET=your_client_secret
export XRAY_PROJECTS=QA,SHOP,PLAT      # comma-separated project keys
export XRAY_DAYS=30                    # optional, default 30

node generate-xray-report.mjs
```
This writes `xray_report_output.html`, ready to archive as a Jenkins build artifact or serve via the HTML Publisher plugin.

## Example Jenkinsfile stage
```groovy
stage('Generate Xray Report') {
  steps {
    withCredentials([
      string(credentialsId: 'xray-client-id', variable: 'XRAY_CLIENT_ID'),
      string(credentialsId: 'xray-client-secret', variable: 'XRAY_CLIENT_SECRET')
    ]) {
      sh '''
        export https_proxy=http://proxy.xxx.com:8080
        export XRAY_PROJECTS=QA,SHOP,PLAT
        export XRAY_DAYS=30
        npm install
        node generate-xray-report.mjs
      '''
    }
  }
}
publishHTML(target: [
  reportName: 'Xray Report',
  reportDir: '.',
  reportFiles: 'xray_report_output.html',
  keepAll: true
])
```
Put credentials in Jenkins Credentials rather than hardcoding them — `client_secret` is a real secret, not something to leave in a shell command in build logs.

## If you still get "connection reset"
That points to the proxy itself rather than the code:
- Wrong proxy host/port, or the proxy requires a username/password (try `http://user:pass@proxy.xxx.com:8080`).
- The proxy uses NTLM/Kerberos auth instead of Basic — `undici`'s `ProxyAgent` only handles Basic auth via the URL form above; NTLM will need a different agent (e.g. a sidecar like `cntlm`) or IT assistance.
- The Jenkins agent's egress firewall blocks the proxy port itself, or blocks `xray.cloud.getxray.app` even via the proxy.
A quick way to isolate it: from the same Jenkins agent shell, run `curl -v --proxy $https_proxy https://xray.cloud.getxray.app/api/v2/authenticate -X POST -d '{}'` — if that also resets, it's purely network/proxy config, not this script.
