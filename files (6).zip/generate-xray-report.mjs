#!/usr/bin/env node
/**
 * generate-xray-report.mjs
 *
 * Runs server-side (e.g. on a Jenkins agent) where https_proxy/HTTPS_PROXY
 * is actually honored. Authenticates against Xray Cloud, pulls test
 * execution + requirement data for each project, and bakes the raw results
 * into a copy of the existing dashboard HTML template. The resulting file
 * is fully self-contained and needs zero network calls when opened later
 * in a browser — avoiding the mixed-content / proxy issues entirely.
 *
 * Requires Node 18+ and the "undici" package (npm install undici).
 *
 * Env vars:
 *   XRAY_CLIENT_ID       (required)
 *   XRAY_CLIENT_SECRET   (required)
 *   XRAY_PROJECTS        (required) comma-separated project keys, e.g. "QA,SHOP"
 *   XRAY_DAYS            (optional) lookback window in days, default 30
 *   TEMPLATE_PATH        (optional) default ./xray_report_template.html
 *   OUTPUT_FILE          (optional) default ./xray_report_output.html
 *   https_proxy / HTTPS_PROXY / http_proxy / HTTP_PROXY  (optional, read automatically)
 */

import { readFile, writeFile } from 'node:fs/promises';
import { setGlobalDispatcher, ProxyAgent } from 'undici';

const XRAY_BASE = 'https://xray.cloud.getxray.app/api/v2';

function setupProxyIfConfigured() {
  const proxyUrl =
    process.env.https_proxy ||
    process.env.HTTPS_PROXY ||
    process.env.http_proxy ||
    process.env.HTTP_PROXY;
  if (proxyUrl) {
    setGlobalDispatcher(new ProxyAgent(proxyUrl));
    console.log(`[proxy] Routing requests through ${proxyUrl}`);
  } else {
    console.log('[proxy] No proxy env var set, calling Xray Cloud directly');
  }
}

async function getXrayToken(clientId, clientSecret) {
  const res = await fetch(`${XRAY_BASE}/authenticate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ client_id: clientId, client_secret: clientSecret }),
  });
  if (!res.ok) {
    throw new Error(`Xray authenticate failed: ${res.status} ${await res.text()}`);
  }
  // Xray's auth endpoint returns the token as a raw JSON string body
  // (matches the original browser code's res.text() behavior).
  return res.text();
}

async function xrayGql(token, query, variables = {}) {
  const res = await fetch(`${XRAY_BASE}/graphql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) {
    throw new Error(`Xray GraphQL HTTP error: ${res.status} ${await res.text()}`);
  }
  const json = await res.json();
  if (json.errors) {
    throw new Error(json.errors.map((e) => e.message).join('; '));
  }
  return json.data;
}

const SPACE_QUERY = `
  query($project:String!,$since:String!){
    getTestExecutions(jql:"project=$project AND created>=$since",limit:100){
      results{
        issueId jira{summary key}
        testPlans(limit:5){results{jira{key summary}}}
        testRuns(limit:200){results{
          id status{name}
          test{jira{key summary}}
          assignee{displayName}
          defects{id summary status{name}}
          finishedOn startedOn
        }}
      }
    }
    getRequirements(jql:"project=$project AND issueType in (Story,Requirement,Epic)",limit:200){
      results{jira{key summary} testCoverage{status}}
    }
  }`;

async function fetchSpace(token, project, days) {
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  return xrayGql(token, SPACE_QUERY, { project, since });
}

function requireEnv(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

async function main() {
  setupProxyIfConfigured();

  const clientId = requireEnv('XRAY_CLIENT_ID');
  const clientSecret = requireEnv('XRAY_CLIENT_SECRET');
  const projects = requireEnv('XRAY_PROJECTS')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const days = parseInt(process.env.XRAY_DAYS || '30', 10);
  const templatePath = process.env.TEMPLATE_PATH || './xray_report_template.html';
  const outputPath = process.env.OUTPUT_FILE || './xray_report_output.html';

  if (projects.length === 0) throw new Error('XRAY_PROJECTS resolved to an empty list');

  console.log('[auth] Requesting Xray Cloud token...');
  const token = await getXrayToken(clientId, clientSecret);

  const rawSpaceData = [];
  for (const project of projects) {
    console.log(`[fetch] ${project} (last ${days} days)...`);
    const data = await fetchSpace(token, project, days);
    rawSpaceData.push({ project, data });
  }

  console.log(`[render] Injecting data into ${templatePath}...`);
  let html = await readFile(templatePath, 'utf8');

  const payload = JSON.stringify({ days, rawSpaceData })
    // Defang </script> sequences so they can't break out of the inline script.
    .replace(/<\/script/gi, '<\\/script');

  const injection = `<script>window.__PRELOADED__=${payload};</script>\n</head>`;
  if (!html.includes('</head>')) {
    throw new Error('Template is missing a </head> tag — cannot inject preloaded data');
  }
  html = html.replace('</head>', injection);

  await writeFile(outputPath, html, 'utf8');
  console.log(`[done] Report written to ${outputPath}`);
}

main().catch((err) => {
  console.error('[error]', err.message);
  process.exit(1);
});
